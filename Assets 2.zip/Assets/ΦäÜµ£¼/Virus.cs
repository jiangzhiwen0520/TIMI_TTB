using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Virus : MonoBehaviour
{
    [SerializeField] private GameObject VirusPrefab;
    [SerializeField] private GameObject Counttime;
    [SerializeField] private GameObject PostionGern;
    [SerializeField] private int minVirusCount;
    [SerializeField] private int maxVirusCount;
    [SerializeField] private Transform[] spawnPoints;
    [SerializeField] private GameObject virusParentObject; // 新增 virusParentObject
    private float virusWidth;
    private float virusHeight;
    private List<Vector3> occupiedPositions = new List<Vector3>();
    private bool hasSpawn = false;

    private void Start()
    {
        virusWidth = VirusPrefab.GetComponent<RectTransform>().rect.width;
        virusHeight = VirusPrefab.GetComponent<RectTransform>().rect.height;
        occupiedPositions.Clear();
    }

    private void Update()
    {
        AddTime();
    }

    private void AddTime()
    {
        if (Counttime.GetComponent<Image>().fillAmount >= 0.98 && !hasSpawn)
        {
            hasSpawn = true;
            int virusCount = Random.Range(minVirusCount, maxVirusCount + 1);

            for (int i = 0; i < virusCount; i++)
            {
                Vector3 randomPos = Vector3.zero;
                bool overlap = true;
                int maxAttempts = 50;
                int attempts = 0;
                while (overlap && attempts < maxAttempts)
                {
                    int randomIndex = Random.Range(0, spawnPoints.Length);
                    randomPos = spawnPoints[randomIndex].position;
                    if (!occupiedPositions.Contains(randomPos))
                    {
                        overlap = false;
                        occupiedPositions.Add(randomPos);
                    }
                    attempts++;
                }

                if (overlap)
                {
                    Debug.LogWarning("Failed to generate a non-overlapping virus after " + maxAttempts + " attempts.");
                    continue;
                }

                GameObject virus = Instantiate(VirusPrefab, randomPos, Quaternion.identity);
                virus.transform.SetParent(virusParentObject.transform); // 设置父物体
                virus.GetComponent<Virus>().enabled = false;
            }

            Counttime.GetComponent<Image>().fillAmount = 0;
            occupiedPositions.Clear();
        }
        else if (Counttime.GetComponent<Image>().fillAmount < 0.5)
        {
            hasSpawn = false;
        }
    }

    private void OnDrawGizmos()
    {
        Gizmos.color = Color.red;
        foreach (Transform spawnPoint in spawnPoints)
        {
            Gizmos.DrawWireCube(spawnPoint.position, new Vector3(virusWidth, virusHeight, 0f));
        }
    }
}
