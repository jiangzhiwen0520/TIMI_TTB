using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class virus2 : MonoBehaviour
{
    [SerializeField] private GameObject VirusPrefab大病毒;
    [SerializeField] private GameObject VirusPrefab中病毒;
    [SerializeField] private GameObject VirusPrefab小病毒;
    [SerializeField] private GameObject VirusPrefab大垃圾;
    [SerializeField] private GameObject VirusPrefab中垃圾;
    [SerializeField] private GameObject VirusPrefab小垃圾;
    [SerializeField] private GameObject Counttime;
    [SerializeField] private RectTransform canvasRect;
    [SerializeField] private int minVirusCount;
    [SerializeField] private int maxVirusCount;
    private Transform virusParentTransform大病毒;
    private Transform virusParentTransform中病毒;
    private Transform virusParentTransform小病毒;
    private Transform virusParentTransform小垃圾;
    private Transform virusParentTransform中垃圾;
    private Transform virusParentTransform大垃圾;
}
