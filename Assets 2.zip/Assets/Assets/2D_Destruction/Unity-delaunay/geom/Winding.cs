namespace Delaunay
{
	namespace Geo {
		public enum Winding
		{
			NONE = 0, CLOCKWISE, COUNTERCLOCKWISE
		}		
	}
}