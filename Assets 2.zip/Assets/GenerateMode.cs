using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class GenerateMode : MonoBehaviour
{
    [SerializeField]private GameObject[] childObjects;
    [SerializeField] private GameObject TimeCount;
    private float startTime;
    private float resetTime = 20f;

    void Start()
    {
        startTime = Time.time;
        GameObject[] canGerenatePoints = GameObject.FindGameObjectsWithTag("SecoundPoints");
    }


    private void Update()
    {
        GenerateMethod();
    }

    private void GenerateMethod()
    {
        GameObject[] canGerenatePoints = GameObject.FindGameObjectsWithTag("SecoundPoints");
        float elapsedTime = Time.time - startTime;
        if (elapsedTime >= resetTime)//最好不用化条因为时间长了会有误差,所以我写了时间重制器
        {
            if (canGerenatePoints.Length <= 5)
            {
                int randomIndex = Random.Range(0, childObjects.Length);//遍历
                for (int i = 0; i < childObjects.Length; i++)
                {

                    bool isActive = i == randomIndex;
                    childObjects[i].SetActive(isActive);
                }
            }
            else if (canGerenatePoints.Length > 5)
            {
                int randomIndex = Random.Range(4, childObjects.Length);//遍历
                for (int i = 0; i < childObjects.Length; i++)
                {

                    bool isActive = i == randomIndex;
                    childObjects[i].SetActive(isActive);
                }
            }
            startTime = Time.time;
        }
    }

    
}
