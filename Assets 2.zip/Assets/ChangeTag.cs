using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ChangeTag : MonoBehaviour
{
    //[SerializeField] private GameObject virus;
    [SerializeField] private GameObject pos;
    [SerializeField] private GameObject pos2;

    private void Start()
    {
        if (pos.transform.childCount == 0)
        {
            pos.gameObject.tag = "SecoundPoints";
            pos2.gameObject.tag = "NoSpace";
        }
        else
        {
            pos.gameObject.tag = "FirstPoints";
            pos2.gameObject.tag = "Space";
        }
    }

    private void Update()
    {
       
        if (pos.transform.childCount==0)
        {
            pos.gameObject.tag = "SecoundPoints";
            pos2.gameObject.tag = "NoSpace";
        }
        else
        {
            pos.gameObject.tag = "FirstPoints";
            pos2.gameObject.tag = "Space";
        }
    }
}
