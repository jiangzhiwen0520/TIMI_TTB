using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class AddText2 : MonoBehaviour
{
    [SerializeField] private GameObject AllPoints;
    [SerializeField] private GameObject Space;
    [SerializeField] private Text progressText;
    
    private void Update()
    {
        int taggedCount = FindCount();
        float fillAmount = (float)taggedCount / 48.0f;
        Space.GetComponent<Image>().fillAmount = fillAmount;

        // 将 fillAmount 转换为 00/20 格式的字符串
        int progress = Mathf.RoundToInt(fillAmount * 20);
        string progressStr = $"{progress:00}/20";
        progressText.text = progressStr;

        // 如果达到 20 则停止遍历
        if (progress >= 20)
        {
            enabled = false;
        }
    }

    private int FindCount()
    {
        int count = 0;
        foreach (Transform child in AllPoints.transform)
        {
            if (child.CompareTag("Space"))
            {
                count++;
            }
        }
        return count;
    }
}
