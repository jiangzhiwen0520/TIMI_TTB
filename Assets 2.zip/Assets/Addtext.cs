using UnityEngine;
using UnityEngine.UI;
using System.Collections; 

public class Addtext : MonoBehaviour
{
    public Text textComponent;
    private int currentCount = 0;
    private int maxCount = 20;

    void Start()
    {
        
        StartCoroutine(IncrementCount());
    }

    IEnumerator IncrementCount()
    {
        while (true)
        {
            // 将UI-Text的文本字符串转换为两个整数
            string[] countStrings = textComponent.text.Split('/');
            int currentCount = int.Parse(countStrings[0]);
            int maxCount = int.Parse(countStrings[1]);

            // 递增第一个整数并将其格式化为两位数
            currentCount++;
            currentCount %= maxCount + 1; // 如果currentCount等于maxCount+1，将其重置为0
            string currentCountString = currentCount.ToString("D2");

            // 将两个整数组合为一个新的字符串并更新UI-Text的文本
            textComponent.text = currentCountString + "/" + maxCount.ToString("D2");

            // 等待1秒
            yield return new WaitForSeconds(1);
        }
    }
}
